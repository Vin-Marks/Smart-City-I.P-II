# Smart_cities
Atividade html/css/js sobre smart cities
